CODE TESTED ONLY IN WINDOWS 10

1. Main source code for all questions is included in LinearRegression.ipynb
2. Run all cells from the top so that the required packages are imported
3. For Q3, the lse function takes in 2 booleans which determines if bias should be added and if whether pseudo-inverse should be done if binary encoding is asked
4. Each function in Q3 is given a brief comment on their funcitonality
5. noiseGen function adds very minute noise to data to tackle sparsity